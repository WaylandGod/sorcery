﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;
using NodeCanvas;

public class PlayMakerActions : FsmStateAction {

	protected void SyncToNC(Blackboard blackboard){

		FsmVariables vars = Fsm.Variables;

		foreach (FsmBool boolVar in vars.BoolVariables){
			if (blackboard.HasData<bool>(boolVar.Name))
				blackboard.SetDataValue(boolVar.Name, boolVar.Value);
		}
		
		foreach (FsmFloat floatVar in vars.FloatVariables){
			if (blackboard.HasData<float>(floatVar.Name))
				blackboard.SetDataValue(floatVar.Name, floatVar.Value);
		}
		
		foreach (FsmInt intVar in vars.IntVariables){
			if (blackboard.HasData<int>(intVar.Name))
				blackboard.SetDataValue(intVar.Name, intVar.Value);
		}
		
		foreach (FsmString stringVar in vars.StringVariables){
			if (blackboard.HasData<string>(stringVar.Name))
				blackboard.SetDataValue(stringVar.Name, stringVar.Value);
		}

		foreach (FsmVector3 vectorVar in vars.Vector3Variables){
			if (blackboard.HasData<Vector3>(vectorVar.Name))
				blackboard.SetDataValue(vectorVar.Name, vectorVar.Value);
		}
		
		foreach (FsmGameObject goVar in vars.GameObjectVariables){
			if (blackboard.HasData<GameObject>(goVar.Name))
				blackboard.SetDataValue(goVar.Name, goVar.Value);
		}
	}

	protected void SyncToPlayMaker(Blackboard blackboard){

		FsmVariables vars = Fsm.Variables;

		foreach (FsmBool boolVar in vars.BoolVariables){
			if (blackboard.HasData<bool>(boolVar.Name))
				boolVar.Value = blackboard.GetDataValue<bool>(boolVar.Name);
		}
		
		foreach (FsmFloat floatVar in vars.FloatVariables){
			if (blackboard.HasData<float>(floatVar.Name))
				floatVar.Value = blackboard.GetDataValue<float>(floatVar.Name);
		}
		
		foreach (FsmInt intVar in vars.IntVariables){
			if (blackboard.HasData<int>(intVar.Name))
				intVar.Value = blackboard.GetDataValue<int>(intVar.Name);
		}
		
		foreach (FsmString stringVar in vars.StringVariables){
			if (blackboard.HasData<string>(stringVar.Name))	
				stringVar.Value = blackboard.GetDataValue<string>(stringVar.Name);
		}

		foreach (FsmVector3 vectorVar in vars.Vector3Variables){
			if (blackboard.HasData<Vector3>(vectorVar.Name))
				vectorVar.Value = blackboard.GetDataValue<Vector3>(vectorVar.Name);
		}
		
		foreach (FsmGameObject goVar in vars.GameObjectVariables){
			if (blackboard.HasData<GameObject>(goVar.Name))
				goVar.Value = blackboard.GetDataValue<GameObject>(goVar.Name);
		}
	}
}
