﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;
using NodeCanvas.DialogueTrees;

[ActionCategory("NodeCanvas")]
[HutongGames.PlayMaker.Tooltip("Starts a NodeCanvas Dialogue Tree")]
public class StartDialogueTree : PlayMakerActions {

	[HutongGames.PlayMaker.RequiredField]
	[HutongGames.PlayMaker.Tooltip("The Dialogue Tree to start")]
	public DialogueTree dialogueTree;

	[HutongGames.PlayMaker.Tooltip("If true, this FSM Variables will be copied to the blackboard")]
	public bool syncVariables = true;

	[HutongGames.PlayMaker.Tooltip("Send when the DialogueTree ends")]
	public FsmEvent finishEvent;

	public override void Reset(){
		dialogueTree = null;
		syncVariables = true;
	}

	public override void OnEnter(){

		if (dialogueTree == null){
			Finish();
			return;
		}

		if (syncVariables && dialogueTree.blackboard != null)
			SyncToNC(dialogueTree.blackboard);

		dialogueTree.StartGraph(OnGraphFinished);
	}

	public override void OnUpdate(){
		
		if (syncVariables && dialogueTree.blackboard != null)
			SyncToPlayMaker(dialogueTree.blackboard);
	}

	void OnGraphFinished(){

		Finish();
		Fsm.Event(finishEvent);
	}

	public override void OnExit(){

		dialogueTree.StopGraph();
		if (syncVariables && dialogueTree.blackboard != null)
			SyncToPlayMaker(dialogueTree.blackboard);
	}
}
