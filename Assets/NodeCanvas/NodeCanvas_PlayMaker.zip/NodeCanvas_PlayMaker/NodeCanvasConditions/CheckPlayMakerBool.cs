﻿using UnityEngine;
using System.Collections.Generic;
using HutongGames.PlayMaker;
using NodeCanvas.Variables;
using System.Linq;

namespace NodeCanvas.Conditions{

	[Category("PlayMaker")]
	[AgentType(typeof(PlayMakerFSM))]
	public class CheckPlayMakerBool : ConditionTask {

		[RequiredField]
		public string boolName;
		public BBBool checkBool;

		protected override string info{
			get
			{
				if (agent == null)
					return "No PlayMakerFSM Selected";
				return "PM Bool '" + boolName + "' == " + checkBool;
			}
		}

		protected override bool OnCheck(){

			return (agent as PlayMakerFSM).FsmVariables.GetFsmBool(boolName).Value == checkBool.value;
		}


		////////////////////////////////////////
		///////////GUI AND EDITOR STUFF/////////
		////////////////////////////////////////
		#if UNITY_EDITOR
		
		protected override void OnTaskInspectorGUI(){

			if (!agent || agent.GetComponent<PlayMakerFSM>() == null){
				UnityEditor.EditorGUILayout.HelpBox("PlayMakerFSM needs to be know prior showing settings", UnityEditor.MessageType.Warning);
				return;
			}

			boolName = EditorUtils.StringPopup("PlayMaker Bool", boolName, agent.GetComponent<PlayMakerFSM>().FsmVariables.BoolVariables.Select(v => v.Name).ToList());
			checkBool = EditorUtils.BBVariableField("Check Bool", checkBool) as BBBool;
		}
		
		#endif
	}
}