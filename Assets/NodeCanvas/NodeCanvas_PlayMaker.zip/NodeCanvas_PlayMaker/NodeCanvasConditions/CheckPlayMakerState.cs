﻿using UnityEngine;
using System.Collections.Generic;
using HutongGames.PlayMaker;
using System.Linq;

namespace NodeCanvas.Conditions{

	[Category("PlayMaker")]
	[AgentType(typeof(PlayMakerFSM))]
	public class CheckPlayMakerState : ConditionTask {

		[RequiredField]
		public string stateName;

		protected override string info{
			get
			{
				if (agent == null)
					return "No PlayMakerFSM Selected";
				return "PM State == '" + stateName + "'";
			}
		}

		protected override bool OnCheck(){

			return (agent as PlayMakerFSM).ActiveStateName == stateName;
		}

		////////////////////////////////////////
		///////////GUI AND EDITOR STUFF/////////
		////////////////////////////////////////
		#if UNITY_EDITOR
		
		protected override void OnTaskInspectorGUI(){

			if (!agent || agent.GetComponent<PlayMakerFSM>() == null){
				UnityEditor.EditorGUILayout.HelpBox("PlayMakerFSM needs to be know prior showing settings", UnityEditor.MessageType.Warning);
				return;
			}

			stateName = EditorUtils.StringPopup("State To Check", stateName, agent.GetComponent<PlayMakerFSM>().FsmStates.Select(s => s.Name).ToList());
		}
		
		#endif
	}
}