﻿using UnityEngine;
using System.Collections.Generic;
using HutongGames.PlayMaker;
using System.Linq;

namespace NodeCanvas.Actions{

	[Category("PlayMaker")]
	[AgentType(typeof(PlayMakerFSM))]
	public class SendPlayMakerEvent : ActionTask {

		[RequiredField]
		public string eventName;

		protected override string info{
			get
			{
				if (agent == null)
					return "No PlayMakerFSM Selected";
				return "Send Event '" + eventName + "' PlayMaker";
			}
		}

		protected override void OnExecute(){

			(agent as PlayMakerFSM).SendEvent(eventName);
			EndAction(true);
		}

		////////////////////////////////////////
		///////////GUI AND EDITOR STUFF/////////
		////////////////////////////////////////
		#if UNITY_EDITOR
		
		protected override void OnTaskInspectorGUI(){

			if (!agent || agent.GetComponent<PlayMakerFSM>() == null){
				UnityEditor.EditorGUILayout.HelpBox("PlayMakerFSM needs to be know prior showing settings", UnityEditor.MessageType.Warning);
				return;
			}

			eventName = EditorUtils.StringPopup("Global Transition Event", eventName, agent.GetComponent<PlayMakerFSM>().FsmGlobalTransitions.Select(t => t.EventName).ToList());
		}
		
		#endif
	}
}